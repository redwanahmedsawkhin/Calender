const days = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
const months = [
  "January", "February", "March", "April", "May", "June",
  "July", "August", "September", "October", "November", "December"
];

const currentDate = new Date();

const dayName = days[currentDate.getDay()];
const date = currentDate.getDate();
const monthName = months[currentDate.getMonth()];
const year = currentDate.getFullYear();

document.getElementById("day").textContent = dayName;
document.getElementById("date").textContent = date;
document.getElementById("month").textContent = monthName;
document.getElementById("year").textContent = year;
